css: format file folder
img: website images folder
src: php files
start.html: start page