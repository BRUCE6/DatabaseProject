<!DOCTYPE html>
<html>
	<head>
		<meta charset = 'UTF-8'>
			
			<meta name = "author" content = "Xiaoran Ni">
			<title><?php print $ptitle ?></title>
			<link rel = "stylesheet" type = "text/css" href = "/Jobster/css/style_index.css" />
			<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
  			<script src="https://code.jquery.com/jquery-migrate-3.0.1.min.js"></script>
  			
			
	</head>

</html>