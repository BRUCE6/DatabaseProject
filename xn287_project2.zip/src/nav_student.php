<div class = "full_nav">
	<header class = "navigation">
		<nav id = "navigation">
			<ul>
				<li><a href = "/Jobster/src/index_student.php">Home</a></li>
				<li><a href = "/Jobster/src/company_student.php">Company</a></li>
				<li><a href = "/Jobster/src/job_student.php">Jobs</a></li>
				<li><a href = "/Jobster/src/people_student.php">People</a></li>
				<li><a href = "/Jobster/src/message.php">Message</a></li>
				<li><a href = "/Jobster/src/notify_student.php">Notifications</a></li>
			</ul>
		</nav>
	</header>
</div>