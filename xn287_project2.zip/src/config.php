<?php
$servername = "localhost";
$db_username = "root";
$db_password = "Wayen.sql006";
$db_name = "jobster";
?>