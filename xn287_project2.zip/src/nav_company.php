<div class = "full_nav">
	<header class = "navigation">
		<nav id = "navigation">
			<ul>
				<li><a href = "/Jobster/src/index_company.php">Home</a></li>
				<li><a href = "/Jobster/src/job_company.php">Jobs</a></li>
				<li><a href = "/Jobster/src/post_job.php">Post</a></li>
				<li><a href = "/Jobster/src/notify_company.php">Notifications</a></li>
			</ul>
		</nav>
	</header>
</div>