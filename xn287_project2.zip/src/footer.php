<html>
</body>
<footer class = "site-footer">
	<center><h3>&copy: 2017-2018 Powered by<a href="https://github.com/BRUCE6">Xiaoran Ni</a></h3></center>
</footer>
<script>
	$(document).ready(function(){

		$("#setting").hover(
				function () {
					$(".setting").stop(true, true).fadeIn("slow");
				}, function () {
					$(".setting").stop(true, true).fadeOut("slow");
				}
			);

		});
</script>

</body>
</html>